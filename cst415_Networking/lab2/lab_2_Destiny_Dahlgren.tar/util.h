void Fatal_Error(const char *msg, ...);
