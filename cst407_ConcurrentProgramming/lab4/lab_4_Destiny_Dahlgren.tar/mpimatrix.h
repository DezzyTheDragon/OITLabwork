void MPI_Matrix_Multiply(double *a, double *b, double *c, 
        int a_cols, int a_rows, int b_cols);
